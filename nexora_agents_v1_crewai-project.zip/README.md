# nexora_agents Flow

This project defines a declarative CrewAI Flow in `src/nexora_agents/flow.yaml`.

## Install

```bash
crewai install
```

## Run

```bash
crewai run
```

Edit the declarative flow definition at `src/nexora_agents/flow.yaml` to change the flow. Add reusable crews under `src/nexora_agents/crews/`, custom Python tools under `src/nexora_agents/tools/`, and shared knowledge files under `src/nexora_agents/knowledge/`.
